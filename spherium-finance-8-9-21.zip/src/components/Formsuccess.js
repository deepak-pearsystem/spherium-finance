import React from 'react';

const Formsuccess = () => {
    return (
        <div>
            <h2>Sucesss</h2>
        </div>
    );
};

export default Formsuccess;